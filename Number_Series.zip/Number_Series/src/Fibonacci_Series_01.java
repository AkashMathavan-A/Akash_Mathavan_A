import java.util.Scanner;

public class Fibonacci_Series_01
{
    static int Fibo(int Num)
    {
        int a=0,b=1,c;
       // int a=1,b=-1,c;
        for(int i=0;i<Num;i++){
            c=a+b;
            //b=a;
            //a=c;
            a=b;
            b=c;
        }
        //return a;
        return b;
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println("Enter the term find in fibonacci series : ");
        int term=in.nextInt();
        System.out.println(term+"th Term of fibonacci series is : "+Fibo(term));
    }
}
