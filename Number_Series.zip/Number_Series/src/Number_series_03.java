import java.util.Scanner;

public class Number_series_03
{
    static void Method(int num){
        int sum=0;
        for(int i=1;i<=num;i++){
            System.out.print(i+"^"+"2" + " + ");
            sum+=i*i;
        }
        System.out.print(" = "+sum);
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.print("Enter the Number : ");
        int num=in.nextInt();
        //1^2 + 2^2 + 3^2 + 4^2 + 5^2 = 55
        Method(num);
    }
}
