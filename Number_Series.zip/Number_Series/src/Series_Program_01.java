import java.util.Scanner;

public class Series_Program_01
{
    static void Series(int Num)
    {
        int i,sum=1;
        for(i=1;i<=Num;i++,sum*=2){
            if(i==Num)
                System.out.print(sum);
            else
                System.out.print(sum+",");
        }
    }
    public static void main(String[] args)
    {
        Scanner in=new Scanner(System.in);
        System.out.println("Enter the limit of the Number : ");
        int Num=in.nextInt();
        Series(Num);
    }
}
