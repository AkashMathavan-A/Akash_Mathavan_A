import java.util.Scanner;

public class Print_Series_01
{
    //1+1/2+1/3+1/4.......
    static void Numbers(int Num)
    {

        float i,sum=0;
        for(i=1;i<=Num;i++){
            sum+=(1/i);
            if(i==1)
                System.out.print("1 + ");
            else if(i==Num)
            System.out.print("1 / " +i);
            else
                System.out.print("1 / " +i+" + ");
        }
        System.out.print(" = "+sum);

    }
    public static void main(String[] args)
    {
        Scanner in=new Scanner(System.in);
        System.out.println("Enter the Number of limits : ");
        int Num=in.nextInt();
        Numbers(Num);
    }
}
