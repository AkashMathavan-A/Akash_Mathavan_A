import java.util.Scanner;

public class Fibonacci_Term
{
    static int fibo(int num)
    {
        if(num==0)
            return 0;
        else if(num==1)
            return 1;
        else
            return fibo(num-1)+fibo(num-2);
    }

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println("Enter the term to find the fibonacci series : ");
        int term=in.nextInt();
        System.out.println(term+"th Term of fibonacci series is : "+(fibo(term)));
    }
}
