public class Number_Series_02
{
    public static void main(String[] args) {
        //Sum of Digits - Another Way
        int num=10,sum=0;
        int result=(num*(num+1))/2;
        System.out.println("Sum of Digits of "+num+" Numbers is : "+result);
    }
}
