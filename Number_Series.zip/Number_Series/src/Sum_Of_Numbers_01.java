import java.util.Scanner;

public class Sum_Of_Numbers_01
{
    static void Sum_Numbers(int num)
    {
     int sum=0;
     for(int i=1;i<=num;i++){
         System.out.print(i+"+");
         sum+=i;
     }
        System.out.print("="+sum);
    }
    public static void main(String[] args)
    {
        Scanner in=new Scanner(System.in);
        System.out.println("Enter the Number to Check the Sum of Numbers series : ");
        int Num=in.nextInt();
        Sum_Numbers(Num);

    }
}
