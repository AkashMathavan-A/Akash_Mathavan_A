public class Series_Program_02
{
    static void Number(int Num)
    {
     int i,sum=1;
     for(i=1;i<=Num;i++,sum=i*i)
     {
         if(i==Num)
             System.out.print(sum);
         else
             System.out.print(sum+",");
     }
    }
    public static void main(String[] args)
    {
        int Num=10;
        Number(Num);
    }
}
