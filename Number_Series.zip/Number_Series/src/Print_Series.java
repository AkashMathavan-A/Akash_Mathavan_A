public class Print_Series
{
    //0,3,8,15,24,35
    public static void main(String[] args) {
        int Num=10;
        int sum=0;
        for(int i=0;i<=Num;i++,sum=i*i-1)
        {
            if(i==Num)
                System.out.print(sum);
            else
                System.out.print(sum+",");
        }
    }
}
