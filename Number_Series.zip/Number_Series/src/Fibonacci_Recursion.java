import java.util.Scanner;

public class Fibonacci_Recursion
{
    static int Fibo(int Num)
    {
        if(Num==0)
            return 0;
       else if(Num==1)
            return 1;
        else
            return Fibo(Num-1)+Fibo(Num-2);
    }

    public static void main(String[] args) {
        Scanner in =new Scanner(System.in);
        System.out.println("Enter the Number of limits : ");
        int num=in.nextInt();
        for(int i=0;i<num;i++)
        System.out.println(Fibo(i));
    }
}
