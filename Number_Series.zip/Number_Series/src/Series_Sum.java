public class Series_Sum
{
    static void Sum(int Num)
    {
        System.out.print("Addition of Square Series : ");
        int sum=1,add=0;
        for(int i=1;i<=Num;i++,sum=i*i)
        {
            if(i==Num)
            System.out.print(sum+" ");
            else
                System.out.print(sum+" + ");
            add+=sum;
        }
        System.out.print(" = "+add);
    }
    public static void main(String[] args)
    {
        int Num=10;
        Sum(Num);

    }
}
