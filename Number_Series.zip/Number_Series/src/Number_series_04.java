public class Number_series_04
{
    public static void main(String[] args) {
        int num=5;
        //Another way
        int result=num * (num+1) * (2 *num+1)/6;
        System.out.println("Result is : "+result);
    }
}
