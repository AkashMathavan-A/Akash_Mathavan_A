import java.util.Scanner;

public class Fibonacci_series
{
    static void fibo(int Num)
    {
        int a=0,b=1,c;
            System.out.print(a+" "+b+" ");
        for(int i=2;i<Num;i++){
            c=a+b;
            System.out.print(c+" ");
            a=b;
            b=c;
        }
    }

    public static void main(String[] args)
    {
        Scanner in=new Scanner(System.in);
        int Num=in.nextInt();
        fibo(Num);
    }
}
