import java.util.Scanner;

public class Series_01
{
    static void Method_01(int Num,int index)
    {
        int sum=0;
        for(int i=0;i<=Num;i++,sum+=i)
        {
            if(i==Num)
                System.out.print(sum);
            else
                System.out.print(sum+",");
        }
        int s=0;
        for(int i=0;i<=index;i++){
            s+=i;
        }
        System.out.println("\n"+index+"th Term is : "+s);
    }
    public static void main(String[] args)
    {
        Scanner in=new Scanner(System.in);
        System.out.println("Enter the Number of terms : ");
        int num=in.nextInt();
        System.out.println("Which term you are find in the above series ? ");
        int index=in.nextInt();
        Method_01(num,index);
    }
}
